/*
 Navicat Premium Data Transfer

 Source Server         : aries
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : pystadb

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 28/04/2019 08:51:51
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for consumption
-- ----------------------------
DROP TABLE IF EXISTS `consumption`;
CREATE TABLE `consumption`  (
  `year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `allmoney` int(10) NULL DEFAULT NULL,
  `ruralmoney` int(10) NULL DEFAULT NULL,
  `urbanmoney` int(10) NULL DEFAULT NULL,
  `allindex` float(10, 1) NULL DEFAULT NULL,
  `ruralindex` float(10, 1) NULL DEFAULT NULL,
  `urbanindex` float(10, 1) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of consumption
-- ----------------------------
INSERT INTO `consumption` VALUES ('2017', 22935, 11691, 31098, 106.0, 107.1, 104.3);
INSERT INTO `consumption` VALUES ('2016', 21285, 10783, 29295, 107.6, 109.3, 105.5);
INSERT INTO `consumption` VALUES ('2015', 19397, 9679, 27210, 107.5, 109.5, 105.4);
INSERT INTO `consumption` VALUES ('2014', 17778, 8711, 25424, 107.7, 109.9, 105.6);
INSERT INTO `consumption` VALUES ('2013', 16190, 7773, 23609, 107.3, 108.6, 105.3);
INSERT INTO `consumption` VALUES ('2012', 14699, 6964, 21861, 109.1, 108.9, 107.2);
INSERT INTO `consumption` VALUES ('2011', 13134, 6187, 19912, 111.0, 112.9, 108.2);
INSERT INTO `consumption` VALUES ('2010', 10919, 4941, 17104, 109.6, 107.4, 107.9);
INSERT INTO `consumption` VALUES ('2009', 9514, 4402, 15127, 109.8, 109.3, 108.0);

-- ----------------------------
-- Table structure for structure
-- ----------------------------
DROP TABLE IF EXISTS `structure`;
CREATE TABLE `structure`  (
  `year` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `total` int(10) NULL DEFAULT NULL,
  `young` int(10) NULL DEFAULT NULL,
  `mid` int(10) NULL DEFAULT NULL,
  `old` int(10) NULL DEFAULT NULL
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of structure
-- ----------------------------
INSERT INTO `structure` VALUES ('2017', 139008, 23348, 99829, 15831);
INSERT INTO `structure` VALUES ('2016', 138271, 23008, 100260, 15003);
INSERT INTO `structure` VALUES ('2015', 137462, 22715, 100361, 14386);
INSERT INTO `structure` VALUES ('2014', 136782, 22558, 100469, 13755);
INSERT INTO `structure` VALUES ('2013', 136072, 22329, 100582, 13161);
INSERT INTO `structure` VALUES ('2012', 135404, 22287, 100403, 12714);
INSERT INTO `structure` VALUES ('2011', 134735, 22164, 100283, 12288);
INSERT INTO `structure` VALUES ('2010', 134091, 22259, 99938, 11894);
INSERT INTO `structure` VALUES ('2009', 133450, 24659, 97484, 11307);
INSERT INTO `structure` VALUES ('2008', 132802, 25166, 96680, 10956);
INSERT INTO `structure` VALUES ('2007', 132129, 25660, 95833, 10636);
INSERT INTO `structure` VALUES ('2006', 131448, 25961, 95068, 10419);
INSERT INTO `structure` VALUES ('2005', 130756, 26504, 94197, 10055);
INSERT INTO `structure` VALUES ('2004', 129988, 27947, 92184, 9857);
INSERT INTO `structure` VALUES ('2003', 129227, 28559, 90976, 9692);
INSERT INTO `structure` VALUES ('2002', 128453, 28774, 90302, 9377);
INSERT INTO `structure` VALUES ('2001', 127627, 28716, 89849, 9062);
INSERT INTO `structure` VALUES ('2000', 126743, 29012, 88910, 8821);
INSERT INTO `structure` VALUES ('1999', 125786, 31950, 85157, 8679);

SET FOREIGN_KEY_CHECKS = 1;
